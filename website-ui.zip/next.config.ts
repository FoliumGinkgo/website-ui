import type { NextConfig } from "next";

// next.config.js
const nextConfig = {
  images: {
    domains: ['192.168.3.21','47.113.217.170'],
  }
};

export default nextConfig;
