import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "@/styles/globals.css";
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// 多语言SEO元数据配置
export const metadata: Metadata = {
  title: {
    default: "鑫航公司 - 专业工程机械配件制造商 | Xinhang Company - Professional Construction Machinery Parts Manufacturer",
    template: "%s | 鑫航公司 | Xinhang Company"
  },
  description: "鑫航公司是专业的工程机械配件制造商，提供高质量的挖掘机斗齿、铲斗等配件产品。Xinhang Company is a professional construction machinery parts manufacturer, providing high-quality excavator bucket teeth, buckets and other parts.",
  keywords: [
    // 中文关键词
    "工程机械配件", "挖掘机斗齿", "铲斗", "机械配件制造", "鑫航公司", "工程机械", "挖掘机配件", "装载机配件",
    // 英文关键词
    "construction machinery parts", "excavator bucket teeth", "bucket", "machinery parts manufacturing", "Xinhang Company", "construction equipment", "excavator parts", "loader parts",
    // 日文关键词
    "建設機械部品", "掘削機バケット歯", "バケット", "機械部品製造",
    // 韩文关键词
    "건설기계 부품", "굴삭기 버킷 치아", "버킷", "기계 부품 제조",
    // 西班牙文关键词
    "piezas de maquinaria de construcción", "dientes de cucharón de excavadora", "cucharón",
    // 法文关键词
    "pièces de machines de construction", "dents de godet d'excavatrice", "godet"
  ].join(", "),
  authors: [{ name: "鑫航公司 | Xinhang Company" }],
  creator: "鑫航公司 | Xinhang Company",
  publisher: "鑫航公司 | Xinhang Company",
  robots: "index, follow",
  alternates: {
    languages: {
      'zh': '/',
      'zh-CN': '/',
      'en': '/en',
      'en-US': '/en',
      'ja': '/ja',
      'ko': '/ko',
      'es': '/es',
      'fr': '/fr',
      'de': '/de',
      'ru': '/ru',
      'x-default': '/'
    }
  },
  openGraph: {
    type: 'website',
    locale: 'zh_CN',
    alternateLocale: ['en_US', 'ja_JP', 'ko_KR', 'es_ES', 'fr_FR', 'de_DE', 'ru_RU'],
    url: 'https://your-domain.com',
    title: '鑫航公司 - 专业工程机械配件制造商 | Xinhang Company - Professional Construction Machinery Parts Manufacturer',
    description: '鑫航公司是专业的工程机械配件制造商，提供高质量的挖掘机斗齿、铲斗等配件产品。Xinhang Company is a professional construction machinery parts manufacturer.',
    siteName: '鑫航公司 | Xinhang Company',
    images: [
      {
        url: '/logo.png',
        width: 1200,
        height: 630,
        alt: '鑫航公司 Logo | Xinhang Company Logo',
      }
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: '鑫航公司 - 专业工程机械配件制造商 | Xinhang Company',
    description: '专业的工程机械配件制造商，提供高质量的挖掘机斗齿、铲斗等配件产品。Professional construction machinery parts manufacturer.',
    images: ['/logo.png'],
  },
  verification: {
    google: 'your-google-verification-code',
    yandex: 'your-yandex-verification-code',
    yahoo: 'your-yahoo-verification-code',
  },
  category: 'Manufacturing',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh" dir="ltr">
      <head>
        {/* 多语言SEO支持 */}
        <link rel="alternate" hrefLang="zh" href="/" />
        <link rel="alternate" hrefLang="zh-CN" href="/" />
        <link rel="alternate" hrefLang="en" href="/en" />
        <link rel="alternate" hrefLang="en-US" href="/en" />
        <link rel="alternate" hrefLang="ja" href="/ja" />
        <link rel="alternate" hrefLang="ko" href="/ko" />
        <link rel="alternate" hrefLang="es" href="/es" />
        <link rel="alternate" hrefLang="fr" href="/fr" />
        <link rel="alternate" hrefLang="de" href="/de" />
        <link rel="alternate" hrefLang="ru" href="/ru" />
        <link rel="alternate" hrefLang="x-default" href="/" />
        
        {/* 地理位置标记 */}
        <meta name="geo.region" content="CN" />
        <meta name="geo.placename" content="China" />
        <meta name="ICBM" content="39.9042,116.4074" />
        
        {/* 多语言结构化数据 */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              "name": {
                "@language": "zh",
                "@value": "鑫航公司"
              },
              "alternateName": [
                {
                  "@language": "en",
                  "@value": "Xinhang Company"
                },
                {
                  "@language": "ja",
                  "@value": "シンハン会社"
                },
                {
                  "@language": "ko",
                  "@value": "신항회사"
                }
              ],
              "description": {
                "@language": "zh",
                "@value": "专业的工程机械配件制造商"
              },
              "url": "https://your-domain.com",
              "logo": "https://your-domain.com/logo.png",
              "image": "https://your-domain.com/logo.png",
              "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "+86-xxx-xxxx-xxxx",
                "contactType": "customer service",
                "availableLanguage": ["Chinese", "English", "Japanese", "Korean", "Spanish", "French", "German", "Russian"]
              },
              "address": {
                "@type": "PostalAddress",
                "addressCountry": "CN",
                "addressRegion": "Your Province",
                "addressLocality": "Your City"
              },
              "sameAs": [
                "https://weibo.com/yourcompany",
                "https://www.linkedin.com/company/yourcompany",
                "https://www.facebook.com/yourcompany",
                "https://twitter.com/yourcompany"
              ],
              "potentialAction": {
                "@type": "SearchAction",
                "target": {
                  "@type": "EntryPoint",
                  "urlTemplate": "https://your-domain.com/search?q={search_term_string}"
                },
                "query-input": "required name=search_term_string"
              }
            })
          }}
        />
        
        {/* 产品结构化数据 */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Product",
              "name": "工程机械配件 | Construction Machinery Parts",
              "description": "高质量的挖掘机斗齿、铲斗等工程机械配件 | High-quality excavator bucket teeth, buckets and other construction machinery parts",
              "brand": {
                "@type": "Brand",
                "name": "鑫航 | Xinhang"
              },
              "manufacturer": {
                "@type": "Organization",
                "name": "鑫航公司 | Xinhang Company"
              },
              "category": "Construction Machinery Parts",
              "offers": {
                "@type": "Offer",
                "availability": "https://schema.org/InStock",
                "priceCurrency": "CNY"
              }
            })
          }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-screen flex flex-col`}>
        <Header />
        <main className="flex-1">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
